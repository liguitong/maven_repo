package org.archive.modules;

public class CandidateChain extends ProcessorChain {

}
